abstract class IVersionRemoteDataSource {
  Future<int> fetchRemoteVersion();
}
